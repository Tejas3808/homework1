from List_s import List_s
l = [ 1,2,3,34 , [1,2,3,45] , (4,5,6,7) , {'s' :345345 , 'o' : 34534}]

obj1 = List_s()
obj1.extract_list(l)



