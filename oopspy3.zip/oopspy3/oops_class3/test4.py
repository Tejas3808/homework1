class ineuron:
    __students = "data science"

    def studetns(self):
        print(ineuron.__students)

i = ineuron()
i.studetns()
#print(i.)


class ineuron:
    __students = "data science"

    def studetns(self):
        print(ineuron.__students)

i = ineuron()
i.studetns()
print(i._ineuron__students)


