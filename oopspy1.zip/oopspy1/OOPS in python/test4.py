class person :

    def age(self, curretn_year , year_of_birth):
        return curretn_year - year_of_birth

    def email_id_input(self, email_id ):
        print("take and mail id form a person and print it " , email_id)

    def ask_name(self):
        name = input("tell me your name ")
        return name

    def ask_dob(self):
        dob = input("tell me your date of birth ")
        return dob

sudh = person()
anuj = person()
gargi = person()
krish = person()
hitesh = person()

sudh.email_id_input("sudhanshu@ineron.ai")
print(sudh.ask_name())

print(hitesh.ask_dob())


"""Task 1 - in a past whatever questions i have given to your with respect to list ,
tuple , dic , set , string try to create a seprate class for each and everyting and
    restructure your code for all the segment and submit .

instruction number 1 -
    always use exception handling
instrruction number 2 :
    use loggging as well

Reformat your code and submit it to me before tomorrwo's' class 3 PM IST to my mail id
sudhanshu@ineuron.ai
sunny.savita@ineuron.ai

i am only looking for your seperate python file in your github link"""


